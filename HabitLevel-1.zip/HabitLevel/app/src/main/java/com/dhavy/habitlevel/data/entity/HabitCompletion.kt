package com.dhavy.habitlevel.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Satu record "checklist" — habit X selesai dilakukan di tanggal Y.
 * epochDay dipakai (bukan Date/String) biar gampang dihitung selisih hari,
 * minggu, dan streak.
 */
@Entity(tableName = "habit_completions", primaryKeys = ["habitId", "epochDay"])
data class HabitCompletion(
    val habitId: Long,
    val epochDay: Long, // java.time.LocalDate.toEpochDay()
    val expEarned: Int,
    val completedAtMillis: Long = System.currentTimeMillis()
)
