package com.dhavy.habitlevel.ui.screens.dashboard

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.HowToReg
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.dhavy.habitlevel.data.entity.Habit
import com.dhavy.habitlevel.domain.StreakCalculator
import com.dhavy.habitlevel.ui.components.HabitCard
import com.dhavy.habitlevel.ui.components.LevelCard
import com.dhavy.habitlevel.ui.theme.AccentSecondary
import com.dhavy.habitlevel.ui.theme.TextPrimary
import com.dhavy.habitlevel.ui.theme.TextSecondary
import com.dhavy.habitlevel.ui.viewmodel.HabitViewModel
import java.time.LocalDate

/**
 * Layar utama (Home). Nunjukin ringkasan level, tombol Absen harian,
 * dan daftar habit hari ini biar user langsung bisa checklist tanpa
 * pindah tab.
 */
@Composable
fun DashboardScreen(
    viewModel: HabitViewModel,
    onHabitClick: (Long) -> Unit,
    onMarkAttendance: () -> Unit
) {
    val habits by viewModel.activeHabits.collectAsStateWithLifecycle()
    val progress by viewModel.userProgress.collectAsStateWithLifecycle()
    val today = remember { LocalDate.now().toEpochDay() }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 24.dp)
    ) {
        item {
            Text("Halo, Dhavy 👋", style = MaterialTheme.typography.headlineMedium, color = TextPrimary)
            Text("Ini progressmu hari ini", style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
        }

        item {
            Spacer(Modifier.height(4.dp))
            LevelCard(level = progress?.level ?: 1, currentExp = progress?.currentExp ?: 0)
        }

        item {
            OutlinedButton(
                onClick = onMarkAttendance,
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Filled.HowToReg, contentDescription = null, tint = AccentSecondary)
                Spacer(Modifier.width(8.dp))
                Text("Absen Hari Ini")
            }
        }

        item {
            Spacer(Modifier.height(4.dp))
            Text(
                "Habit Hari Ini",
                style = MaterialTheme.typography.titleLarge,
                color = TextPrimary,
                fontWeight = FontWeight.Bold
            )
        }

        if (habits.isEmpty()) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                    Column(Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Belum ada habit.", color = TextSecondary)
                        Text("Buat habit pertamamu di tab Habits!", color = TextSecondary, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        } else {
            items(habits, key = { it.id }) { habit: Habit ->
                HabitRow(habit = habit, today = today, viewModel = viewModel, onClick = { onHabitClick(habit.id) })
            }
        }
    }
}

@Composable
private fun HabitRow(
    habit: Habit,
    today: Long,
    viewModel: HabitViewModel,
    onClick: () -> Unit
) {
    // Ambil snapshot completions per habit secara reaktif dari repository via composable state
    var isDoneToday by remember(habit.id) { mutableStateOf(false) }
    var streak by remember(habit.id) { mutableStateOf(0) }

    LaunchedEffect(habit.id) {
        viewModel.observeHabitCompletions(habit.id).collect { completions ->
            isDoneToday = completions.any { it.epochDay == today }
            streak = StreakCalculator.currentStreak(completions, today)
        }
    }

    HabitCard(
        habit = habit,
        isDoneToday = isDoneToday,
        streak = streak,
        onToggle = { viewModel.toggleHabitDone(habit.id, today, isDoneToday) },
        onClick = onClick
    )
}
