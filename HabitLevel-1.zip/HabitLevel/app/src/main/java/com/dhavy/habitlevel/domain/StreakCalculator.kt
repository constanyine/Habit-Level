package com.dhavy.habitlevel.domain

import com.dhavy.habitlevel.data.entity.HabitCompletion

/**
 * Ngitung streak (fitur "api" ala TikTok) dari list HabitCompletion.
 * Streak putus kalau ada hari yang bolong sebelum hari ini.
 */
object StreakCalculator {

    /**
     * @param completions semua completion untuk 1 habit, tidak harus urut
     * @param todayEpochDay epochDay hari ini (java.time.LocalDate.now().toEpochDay())
     * @return jumlah hari streak berjalan (0 kalau kemarin/hari ini belum checklist)
     */
    fun currentStreak(completions: List<HabitCompletion>, todayEpochDay: Long): Int {
        val completedDays = completions.map { it.epochDay }.toHashSet()

        // Streak dihitung mundur dari hari ini. Kalau hari ini belum checklist,
        // masih dianggap "streak belum putus" selama kemarin ada — biar user
        // yang belum sempat checklist di jam segini gak langsung kehilangan api-nya.
        var streak = 0
        var day = todayEpochDay
        if (!completedDays.contains(day)) {
            day -= 1
        }
        while (completedDays.contains(day)) {
            streak += 1
            day -= 1
        }
        return streak
    }
}
