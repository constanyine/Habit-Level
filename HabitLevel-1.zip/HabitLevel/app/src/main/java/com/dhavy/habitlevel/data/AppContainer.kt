package com.dhavy.habitlevel.data

import android.content.Context
import com.dhavy.habitlevel.data.repository.HabitRepository
import com.dhavy.habitlevel.data.repository.SleepRepository

/**
 * Container dependency sederhana. Dibuat manual (tanpa Hilt/Koin) supaya
 * gampang dibaca & di-debug pemula. Kalau project makin besar, ini bisa
 * diganti Hilt tanpa mengubah repository/ViewModel-nya.
 */
class AppContainer(context: Context) {
    private val database = AppDatabase.getInstance(context)

    val habitRepository: HabitRepository by lazy {
        HabitRepository(database.habitDao(), database.userProgressDao())
    }

    val sleepRepository: SleepRepository by lazy {
        SleepRepository(database.sleepDao())
    }
}
