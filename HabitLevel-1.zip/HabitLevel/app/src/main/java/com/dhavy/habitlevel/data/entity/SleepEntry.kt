package com.dhavy.habitlevel.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Catatan tidur per hari — dipakai buat diagram garis progression tidur.
 */
@Entity(tableName = "sleep_entries")
data class SleepEntry(
    @PrimaryKey val epochDay: Long,
    val sleepDurationMinutes: Int,
    val sleepQualityRating: Int? = null // opsional, 1-5, kalau mau tambah rating kualitas
)
