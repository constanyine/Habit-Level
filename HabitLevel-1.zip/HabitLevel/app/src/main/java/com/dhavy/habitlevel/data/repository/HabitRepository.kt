package com.dhavy.habitlevel.data.repository

import com.dhavy.habitlevel.data.dao.HabitDao
import com.dhavy.habitlevel.data.dao.UserProgressDao
import com.dhavy.habitlevel.data.entity.Habit
import com.dhavy.habitlevel.data.entity.HabitCompletion
import com.dhavy.habitlevel.data.entity.UserProgress
import com.dhavy.habitlevel.domain.ExpCalculator
import com.dhavy.habitlevel.domain.StreakCalculator
import java.time.LocalDate

/**
 * Ini satu-satunya tempat yang "boleh" ngasih EXP ke user —
 * ViewModel/UI cuma manggil fungsi ini, gak pernah nulis exp secara langsung.
 * Itu yang bikin sistem exp "otomatis" dan konsisten.
 */
class HabitRepository(
    private val habitDao: HabitDao,
    private val userProgressDao: UserProgressDao
) {
    fun observeActiveHabits() = habitDao.getActiveHabits()

    suspend fun createHabit(habit: Habit) = habitDao.insertHabit(habit)

    fun observeUserProgress() = userProgressDao.observeProgress()

    fun observeCompletionsForHabit(habitId: Long) = habitDao.getAllCompletionsForHabit(habitId)

    suspend fun getCompletionsSnapshot(habitId: Long) = habitDao.getAllCompletionsForHabitSnapshot(habitId)

    /** Fitur Absen: check-in umum harian, terpisah dari checklist habit spesifik. */
    suspend fun markAttendanceToday(): Int {
        val today = LocalDate.now().toEpochDay()
        val progress = userProgressDao.getProgress() ?: UserProgress()
        if (progress.lastAttendanceEpochDay == today) return 0 // sudah absen hari ini

        val newStreak = if (progress.lastAttendanceEpochDay == today - 1) {
            progress.currentAttendanceStreak + 1
        } else 1
        val exp = ExpCalculator.calculateAttendanceExp(newStreak)

        val withAttendance = progress.copy(
            currentAttendanceStreak = newStreak,
            longestAttendanceStreak = maxOf(progress.longestAttendanceStreak, newStreak),
            lastAttendanceEpochDay = today
        )
        val (updated, levelsGained) = ExpCalculator.applyExp(withAttendance, exp)
        userProgressDao.upsert(updated)
        return levelsGained
    }

    /**
     * Dipanggil saat user checklist habit di hari tertentu.
     * @return jumlah level yang naik (0 kalau belum naik level) — dipakai UI buat animasi "LEVEL UP!"
     */
    suspend fun markHabitDone(habitId: Long, epochDay: Long = LocalDate.now().toEpochDay()): Int {
        val habit = habitDao.getHabitById(habitId) ?: return 0

        // Streak dihitung SEBELUM hari ini ditambahkan, karena bonus streak
        // dihitung dari "momentum" yang sudah dibangun sebelumnya.
        val existing = habitDao.getAllCompletionsForHabitSnapshot(habitId)
        val streakBefore = StreakCalculator.currentStreak(existing, epochDay - 1)

        val exp = ExpCalculator.calculateExpForCompletion(habit.difficulty, streakBefore)
        habitDao.upsertCompletion(HabitCompletion(habitId, epochDay, exp))

        val progress = userProgressDao.getProgress() ?: UserProgress()
        val (updated, levelsGained) = ExpCalculator.applyExp(progress, exp)
        userProgressDao.upsert(updated)

        return levelsGained
    }

    suspend fun unmarkHabitDone(habitId: Long, epochDay: Long) {
        // Catatan: sengaja TIDAK menarik kembali EXP yang sudah didapat,
        // biar user gak "dihukum" kalau salah pencet lalu batalin. EXP yang
        // sudah diberi tetap milik user; cukup checklist-nya yang dihapus.
        habitDao.removeCompletion(habitId, epochDay)
    }

    /** Dipanggil oleh fitur Reset Progress (di Settings, dengan konfirmasi). */
    suspend fun resetAllProgress() {
        userProgressDao.resetLevelAndExp()
    }
}
