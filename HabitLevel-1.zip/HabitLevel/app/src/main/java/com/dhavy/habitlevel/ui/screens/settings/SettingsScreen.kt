package com.dhavy.habitlevel.ui.screens.settings

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.dhavy.habitlevel.data.repository.HabitRepository
import com.dhavy.habitlevel.ui.theme.TextPrimary
import com.dhavy.habitlevel.ui.theme.TextSecondary
import kotlinx.coroutines.launch

/**
 * Sengaja ditaruh di sub-layar Settings (bukan tab utama / bottom nav),
 * sesuai requirement: reset progress harus "tersembunyi" biar gak kepencet
 * gak sengaja. Konfirmasi dibuat 2 langkah.
 */
@Composable
fun SettingsScreen(
    repository: HabitRepository,
    onBack: () -> Unit
) {
    var showConfirmStep1 by remember { mutableStateOf(false) }
    var showConfirmStep2 by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) {
                Icon(Icons.Filled.ArrowBack, contentDescription = "Kembali", tint = TextPrimary)
            }
            Text("Pengaturan", style = MaterialTheme.typography.headlineMedium, color = TextPrimary)
        }

        Spacer(Modifier.height(24.dp))
        Text("Zona Berbahaya", style = MaterialTheme.typography.titleMedium, color = TextSecondary)
        Spacer(Modifier.height(8.dp))

        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
            Column(Modifier.padding(16.dp)) {
                Text("Reset Progress", color = TextPrimary, style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(4.dp))
                Text(
                    "Level dan EXP akan kembali ke awal. Habit dan riwayat checklist TIDAK dihapus.",
                    color = TextSecondary,
                    style = MaterialTheme.typography.bodyMedium
                )
                Spacer(Modifier.height(12.dp))
                OutlinedButton(
                    onClick = { showConfirmStep1 = true },
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFFF6B6B))
                ) {
                    Icon(Icons.Filled.DeleteForever, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("Reset Progress")
                }
            }
        }
    }

    if (showConfirmStep1) {
        AlertDialog(
            onDismissRequest = { showConfirmStep1 = false },
            title = { Text("Yakin mau reset?") },
            text = { Text("Level dan EXP kamu akan hilang dan gak bisa dikembalikan.") },
            confirmButton = {
                TextButton(onClick = {
                    showConfirmStep1 = false
                    showConfirmStep2 = true
                }) { Text("Lanjutkan") }
            },
            dismissButton = {
                TextButton(onClick = { showConfirmStep1 = false }) { Text("Batal") }
            }
        )
    }

    if (showConfirmStep2) {
        AlertDialog(
            onDismissRequest = { showConfirmStep2 = false },
            title = { Text("Konfirmasi terakhir") },
            text = { Text("Ini gak bisa dibatalin. Reset sekarang?") },
            confirmButton = {
                TextButton(onClick = {
                    showConfirmStep2 = false
                    scope.launch { repository.resetAllProgress() }
                }) { Text("Ya, Reset") }
            },
            dismissButton = {
                TextButton(onClick = { showConfirmStep2 = false }) { Text("Batal") }
            }
        )
    }
}
