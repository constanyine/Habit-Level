package com.dhavy.habitlevel.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.dhavy.habitlevel.data.entity.SleepEntry
import kotlinx.coroutines.flow.Flow

@Dao
interface SleepDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertSleepEntry(entry: SleepEntry)

    @Query("SELECT * FROM sleep_entries WHERE epochDay BETWEEN :startEpochDay AND :endEpochDay ORDER BY epochDay ASC")
    fun observeSleepInRange(startEpochDay: Long, endEpochDay: Long): Flow<List<SleepEntry>>
}
