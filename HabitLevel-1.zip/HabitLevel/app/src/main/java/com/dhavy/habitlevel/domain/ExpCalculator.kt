package com.dhavy.habitlevel.domain

import com.dhavy.habitlevel.data.entity.HabitDifficulty
import com.dhavy.habitlevel.data.entity.UserProgress
import kotlin.math.pow
import kotlin.math.roundToInt

/**
 * Ini "game engine"-nya. User TIDAK PERNAH input EXP manual —
 * semua dihitung otomatis dari sini berdasarkan aksi yang mereka lakukan.
 *
 * Kenapa gak dibuat gede2: base EXP sengaja kecil (5-15) dan streak bonus
 * dicap max +10, supaya level up itu terasa seperti pencapaian, bukan
 * angka yang meledak dalam sehari.
 */
object ExpCalculator {

    private const val STREAK_BONUS_INTERVAL = 5 // tiap kelipatan 5 hari streak
    private const val STREAK_BONUS_PER_INTERVAL = 1
    private const val STREAK_BONUS_CAP = 10

    /**
     * Hitung EXP yang didapat untuk satu checklist habit.
     * @param currentStreakForHabit streak berjalan untuk habit spesifik ini (dalam hari)
     */
    fun calculateExpForCompletion(difficulty: HabitDifficulty, currentStreakForHabit: Int): Int {
        val base = difficulty.baseExp
        val streakBonus = minOf(
            (currentStreakForHabit / STREAK_BONUS_INTERVAL) * STREAK_BONUS_PER_INTERVAL,
            STREAK_BONUS_CAP
        )
        return base + streakBonus
    }

    /** EXP kecil buat fitur Absen harian (terpisah dari habit checklist). */
    fun calculateAttendanceExp(currentAttendanceStreak: Int): Int {
        val base = 3
        val bonus = minOf(currentAttendanceStreak / 7, 5) // tiap seminggu penuh +1, cap +5
        return base + bonus
    }

    /**
     * Kurva EXP dibutuhkan buat naik ke level berikutnya.
     * Kurva kuadratik-ringan ala RPG: 100, 283, 520, ... makin lama makin susah.
     */
    fun expRequiredForLevel(level: Int): Int {
        return (100 * level.toDouble().pow(1.5)).roundToInt()
    }

    /**
     * Terapkan EXP yang baru didapat ke UserProgress, handle level-up
     * (bisa naik lebih dari 1 level sekaligus kalau EXP-nya besar).
     *
     * @return progress baru + berapa level yang naik (0 kalau belum naik level)
     */
    fun applyExp(current: UserProgress, expGained: Int): Pair<UserProgress, Int> {
        var level = current.level
        var exp = current.currentExp + expGained
        var levelsGained = 0

        while (exp >= expRequiredForLevel(level)) {
            exp -= expRequiredForLevel(level)
            level += 1
            levelsGained += 1
        }

        return current.copy(level = level, currentExp = exp) to levelsGained
    }
}
