package com.dhavy.habitlevel.ui.screens.profile

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.dhavy.habitlevel.ui.components.LevelCard
import com.dhavy.habitlevel.ui.theme.StreakFire
import com.dhavy.habitlevel.ui.theme.TextPrimary
import com.dhavy.habitlevel.ui.theme.TextSecondary
import com.dhavy.habitlevel.ui.viewmodel.HabitViewModel

@Composable
fun ProfileScreen(
    viewModel: HabitViewModel,
    onOpenSettings: () -> Unit
) {
    val progress by viewModel.userProgress.collectAsStateWithLifecycle()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Profil", style = MaterialTheme.typography.headlineMedium, color = TextPrimary)
            IconButton(onClick = onOpenSettings) {
                Icon(Icons.Filled.Settings, contentDescription = "Pengaturan", tint = TextPrimary)
            }
        }

        Spacer(Modifier.height(16.dp))
        LevelCard(level = progress?.level ?: 1, currentExp = progress?.currentExp ?: 0)

        Spacer(Modifier.height(16.dp))
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
            Column(Modifier.padding(20.dp)) {
                Text("Absen & Kedisiplinan", style = MaterialTheme.typography.titleLarge, color = TextPrimary, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(12.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.LocalFireDepartment, contentDescription = null, tint = StreakFire)
                    Spacer(Modifier.width(8.dp))
                    Column {
                        Text(
                            "Streak absen saat ini: ${progress?.currentAttendanceStreak ?: 0} hari",
                            color = TextPrimary,
                            style = MaterialTheme.typography.bodyLarge
                        )
                        Text(
                            "Rekor terpanjang: ${progress?.longestAttendanceStreak ?: 0} hari",
                            color = TextSecondary,
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }
            }
        }
    }
}
