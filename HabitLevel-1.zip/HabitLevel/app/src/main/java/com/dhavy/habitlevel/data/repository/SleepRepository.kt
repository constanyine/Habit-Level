package com.dhavy.habitlevel.data.repository

import com.dhavy.habitlevel.data.dao.SleepDao
import com.dhavy.habitlevel.data.entity.SleepEntry

class SleepRepository(private val sleepDao: SleepDao) {

    fun observeSleepInRange(startEpochDay: Long, endEpochDay: Long) =
        sleepDao.observeSleepInRange(startEpochDay, endEpochDay)

    suspend fun logSleep(epochDay: Long, durationMinutes: Int, quality: Int? = null) {
        sleepDao.upsertSleepEntry(SleepEntry(epochDay, durationMinutes, quality))
    }
}
