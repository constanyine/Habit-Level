package com.dhavy.habitlevel.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.dhavy.habitlevel.data.entity.Habit
import com.dhavy.habitlevel.data.repository.HabitRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.LocalDate

/** Event sekali-pakai buat trigger animasi/dialog "LEVEL UP!" di UI. */
sealed class HabitEvent {
    data class LevelUp(val levelsGained: Int) : HabitEvent()
}

class HabitViewModel(private val repository: HabitRepository) : ViewModel() {

    val activeHabits: StateFlow<List<Habit>> = repository.observeActiveHabits()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val userProgress = repository.observeUserProgress()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    private val _events = MutableStateFlow<HabitEvent?>(null)
    val events: StateFlow<HabitEvent?> = _events

    fun createHabit(
        name: String,
        category: com.dhavy.habitlevel.data.entity.HabitCategory,
        difficulty: com.dhavy.habitlevel.data.entity.HabitDifficulty,
        targetDaysPerWeek: Int,
        reminderHour: Int?,
        reminderMinute: Int?,
        onCreated: (Long) -> Unit = {}
    ) {
        viewModelScope.launch {
            val id = repository.createHabit(
                Habit(
                    name = name,
                    category = category,
                    difficulty = difficulty,
                    targetDaysPerWeek = targetDaysPerWeek,
                    createdAtEpochDay = LocalDate.now().toEpochDay(),
                    reminderHour = reminderHour,
                    reminderMinute = reminderMinute
                )
            )
            onCreated(id)
        }
    }

    fun toggleHabitDone(habitId: Long, epochDay: Long, alreadyDone: Boolean) {
        viewModelScope.launch {
            if (alreadyDone) {
                repository.unmarkHabitDone(habitId, epochDay)
            } else {
                val levelsGained = repository.markHabitDone(habitId, epochDay)
                if (levelsGained > 0) {
                    _events.value = HabitEvent.LevelUp(levelsGained)
                }
            }
        }
    }

    fun observeHabitCompletions(habitId: Long) = repository.observeCompletionsForHabit(habitId)

    fun markAttendance() {
        viewModelScope.launch {
            val levelsGained = repository.markAttendanceToday()
            if (levelsGained > 0) {
                _events.value = HabitEvent.LevelUp(levelsGained)
            }
        }
    }

    fun consumeEvent() {
        _events.value = null
    }

    class Factory(private val repository: HabitRepository) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return HabitViewModel(repository) as T
        }
    }
}
