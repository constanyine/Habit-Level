package com.dhavy.habitlevel.ui.screens.habits

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.dhavy.habitlevel.data.entity.HabitCategory
import com.dhavy.habitlevel.data.entity.HabitDifficulty
import com.dhavy.habitlevel.ui.components.categoryColor

@Composable
fun AddHabitDialog(
    onDismiss: () -> Unit,
    onConfirm: (
        name: String,
        category: HabitCategory,
        difficulty: HabitDifficulty,
        targetDaysPerWeek: Int,
        reminderHour: Int?,
        reminderMinute: Int?
    ) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf(HabitCategory.FISIKAL) }
    var selectedDifficulty by remember { mutableStateOf(HabitDifficulty.MEDIUM) }
    var targetDays by remember { mutableStateOf(7f) }
    var reminderEnabled by remember { mutableStateOf(false) }
    var reminderHour by remember { mutableStateOf(20) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = MaterialTheme.shapes.large
        ) {
            Column(
                Modifier
                    .padding(20.dp)
                    .fillMaxWidth()
            ) {
                Text("Habit Baru", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(16.dp))

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Nama habit") },
                    placeholder = { Text("misal: Lari pagi") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                Spacer(Modifier.height(16.dp))
                Text("Kategori", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))
                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    modifier = Modifier.height(150.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(HabitCategory.entries.toList()) { cat ->
                        CategoryChip(
                            category = cat,
                            selected = cat == selectedCategory,
                            onClick = { selectedCategory = cat }
                        )
                    }
                }

                Spacer(Modifier.height(16.dp))
                Text("Tingkat Kesulitan", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    HabitDifficulty.entries.forEach { diff ->
                        FilterChip(
                            selected = diff == selectedDifficulty,
                            onClick = { selectedDifficulty = diff },
                            label = { Text(diff.name) }
                        )
                    }
                }

                Spacer(Modifier.height(16.dp))
                Text(
                    "Limit hari per minggu buat 100%: ${targetDays.toInt()} hari",
                    style = MaterialTheme.typography.titleMedium
                )
                Slider(
                    value = targetDays,
                    onValueChange = { targetDays = it },
                    valueRange = 1f..7f,
                    steps = 5
                )

                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = reminderEnabled, onCheckedChange = { reminderEnabled = it })
                    Text("Ingatkan jam")
                    Spacer(Modifier.width(8.dp))
                    if (reminderEnabled) {
                        OutlinedTextField(
                            value = reminderHour.toString(),
                            onValueChange = { reminderHour = it.toIntOrNull()?.coerceIn(0, 23) ?: reminderHour },
                            modifier = Modifier.width(70.dp),
                            singleLine = true,
                            label = { Text("Jam") }
                        )
                    }
                }

                Spacer(Modifier.height(20.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = onDismiss) { Text("Batal") }
                    Spacer(Modifier.width(8.dp))
                    Button(
                        onClick = {
                            if (name.isNotBlank()) {
                                onConfirm(
                                    name.trim(),
                                    selectedCategory,
                                    selectedDifficulty,
                                    targetDays.toInt(),
                                    if (reminderEnabled) reminderHour else null,
                                    if (reminderEnabled) 0 else null
                                )
                            }
                        },
                        enabled = name.isNotBlank()
                    ) {
                        Text("Simpan")
                    }
                }
            }
        }
    }
}

@Composable
private fun CategoryChip(category: HabitCategory, selected: Boolean, onClick: () -> Unit) {
    FilterChip(
        selected = selected,
        onClick = onClick,
        label = { Text("${category.emoji} ${category.displayName}") },
        colors = FilterChipDefaults.filterChipColors(
            selectedContainerColor = categoryColor(category).copy(alpha = 0.3f)
        )
    )
}
