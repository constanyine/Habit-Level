package com.dhavy.habitlevel.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColors = darkColorScheme(
    background = BackgroundDark,
    surface = SurfaceDark,
    surfaceVariant = SurfaceElevated,
    primary = AccentPrimary,
    secondary = AccentSecondary,
    onBackground = TextPrimary,
    onSurface = TextPrimary,
    onPrimary = Color.White,
)

@Composable
fun HabitLevelTheme(
    // App ini dirancang gamified & gelap secara default (enak di mata malam hari).
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = DarkColors,
        typography = AppTypography,
        content = content
    )
}
