package com.dhavy.habitlevel.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Single-row table (id selalu 1) yang nyimpen status "karakter" user:
 * level, exp saat ini, dan longest/current overall streak dari fitur Absen.
 */
@Entity(tableName = "user_progress")
data class UserProgress(
    @PrimaryKey val id: Int = 1,
    val level: Int = 1,
    val currentExp: Int = 0,
    val currentAttendanceStreak: Int = 0,
    val longestAttendanceStreak: Int = 0,
    val lastAttendanceEpochDay: Long? = null
)
