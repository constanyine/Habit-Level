package com.dhavy.habitlevel.data.dao

import androidx.room.*
import com.dhavy.habitlevel.data.entity.Habit
import com.dhavy.habitlevel.data.entity.HabitCompletion
import kotlinx.coroutines.flow.Flow

@Dao
interface HabitDao {

    @Insert
    suspend fun insertHabit(habit: Habit): Long

    @Update
    suspend fun updateHabit(habit: Habit)

    @Query("SELECT * FROM habits WHERE isArchived = 0 ORDER BY createdAtEpochDay DESC")
    fun getActiveHabits(): Flow<List<Habit>>

    @Query("SELECT * FROM habits WHERE id = :habitId")
    suspend fun getHabitById(habitId: Long): Habit?

    @Query("UPDATE habits SET isArchived = 1 WHERE id = :habitId")
    suspend fun archiveHabit(habitId: Long)

    // ---- Completions (checklist) ----

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertCompletion(completion: HabitCompletion)

    @Query("DELETE FROM habit_completions WHERE habitId = :habitId AND epochDay = :epochDay")
    suspend fun removeCompletion(habitId: Long, epochDay: Long)

    @Query("SELECT * FROM habit_completions WHERE habitId = :habitId AND epochDay BETWEEN :startEpochDay AND :endEpochDay")
    suspend fun getCompletionsInRange(habitId: Long, startEpochDay: Long, endEpochDay: Long): List<HabitCompletion>

    @Query("SELECT * FROM habit_completions WHERE habitId = :habitId ORDER BY epochDay DESC")
    fun getAllCompletionsForHabit(habitId: Long): Flow<List<HabitCompletion>>

    @Query("SELECT * FROM habit_completions WHERE habitId = :habitId ORDER BY epochDay DESC")
    suspend fun getAllCompletionsForHabitSnapshot(habitId: Long): List<HabitCompletion>

    @Query("SELECT * FROM habit_completions WHERE habitId = :habitId AND epochDay = :epochDay LIMIT 1")
    suspend fun getCompletion(habitId: Long, epochDay: Long): HabitCompletion?
}
