package com.dhavy.habitlevel.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.dhavy.habitlevel.data.entity.SleepEntry
import com.dhavy.habitlevel.data.repository.SleepRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.LocalDate

class SleepViewModel(private val repository: SleepRepository) : ViewModel() {

    private val today = LocalDate.now().toEpochDay()
    private val rangeStart = today - 29 // 30 hari terakhir buat diagram garis

    val recentSleep: StateFlow<List<SleepEntry>> =
        repository.observeSleepInRange(rangeStart, today)
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun logSleep(hours: Float, quality: Int?) {
        viewModelScope.launch {
            repository.logSleep(LocalDate.now().toEpochDay(), (hours * 60).toInt(), quality)
        }
    }

    class Factory(private val repository: SleepRepository) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return SleepViewModel(repository) as T
        }
    }
}
