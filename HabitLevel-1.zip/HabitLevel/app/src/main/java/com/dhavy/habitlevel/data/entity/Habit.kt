package com.dhavy.habitlevel.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Satu habit yang dibuat user sendiri.
 *
 * @param targetDaysPerWeek "limit" mingguan — berapa hari dalam seminggu
 *   yang dianggap 100% selesai. Misal diisi 6, checklist 6 hari = 100%,
 *   walau minggu ada 7 hari.
 * @param reminderHour / reminderMinute waktu notifikasi pengingat (nullable kalau tidak diaktifkan)
 */
@Entity(tableName = "habits")
data class Habit(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val category: HabitCategory,
    val difficulty: HabitDifficulty = HabitDifficulty.MEDIUM,
    val targetDaysPerWeek: Int = 7,
    val createdAtEpochDay: Long,
    val reminderHour: Int? = null,
    val reminderMinute: Int? = null,
    val isArchived: Boolean = false
)
