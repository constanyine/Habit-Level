package com.dhavy.habitlevel.data.entity

/**
 * Kategori habit. Tambahin sendiri di sini kalau mau kategori baru,
 * tinggal kasih displayName & emoji-nya.
 */
enum class HabitCategory(val displayName: String, val emoji: String) {
    FISIKAL("Fisikal", "\uD83D\uDCAA"),
    MENTAL("Mental", "\uD83E\uDDE0"),
    INTELEKTUAL("Intelektual", "\uD83D\uDCDA"),
    SOSIAL("Sosial", "\uD83E\uDD1D"),
    SPIRITUAL("Spiritual", "\uD83D\uDE4F"),
    KREATIVITAS("Kreativitas", "\uD83C\uDFA8"),
    FINANSIAL("Finansial", "\uD83D\uDCB0"),
    PRODUKTIVITAS("Produktivitas", "\uD83D\uDCC8")
}

enum class HabitDifficulty(val baseExp: Int) {
    EASY(5),
    MEDIUM(10),
    HARD(15)
}
