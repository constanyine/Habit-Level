package com.dhavy.habitlevel.ui.theme

import androidx.compose.ui.graphics.Color

// Background & surface — dark, soft di mata (bukan hitam pekat #000)
val BackgroundDark = Color(0xFF0F1020)
val SurfaceDark = Color(0xFF1A1B2E)
val SurfaceElevated = Color(0xFF23243D)

// Aksen utama — biru-ungu ala "sistem" RPG
val AccentPrimary = Color(0xFF7C6CFF)
val AccentSecondary = Color(0xFF00D9C0)

// Status warna
val StreakFire = Color(0xFFFF7A45)
val ExpBar = Color(0xFF7C6CFF)
val SuccessGreen = Color(0xFF4ADE80)
val WarningYellow = Color(0xFFFACC15)

// Kategori (dipetakan di komponen, warna soft biar gak norak)
val CategoryFisikal = Color(0xFFFF6B6B)
val CategoryMental = Color(0xFF9B7BFF)
val CategoryIntelektual = Color(0xFF4DABF7)
val CategorySosial = Color(0xFFFFA94D)
val CategorySpiritual = Color(0xFFB197FC)
val CategoryKreativitas = Color(0xFFFF8FB1)
val CategoryFinansial = Color(0xFF63E6BE)
val CategoryProduktivitas = Color(0xFF66D9EF)

// Teks
val TextPrimary = Color(0xFFF2F2F7)
val TextSecondary = Color(0xFFA0A0B8)
