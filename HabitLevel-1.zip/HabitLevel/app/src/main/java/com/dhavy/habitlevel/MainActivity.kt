package com.dhavy.habitlevel

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.dhavy.habitlevel.ui.navigation.HabitLevelNavGraph
import com.dhavy.habitlevel.ui.theme.HabitLevelTheme

class MainActivity : ComponentActivity() {

    private val notificationPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { /* hasil izin, gak wajib ditangani khusus */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        val container = (application as HabitLevelApplication).container

        setContent {
            HabitLevelTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    HabitLevelNavGraph(container = container)
                }
            }
        }
    }
}
