package com.dhavy.habitlevel.ui.screens.weekly

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.dhavy.habitlevel.data.entity.Habit
import com.dhavy.habitlevel.domain.WeeklyProgressCalculator
import com.dhavy.habitlevel.ui.components.WeekDotsRow
import com.dhavy.habitlevel.ui.theme.TextPrimary
import com.dhavy.habitlevel.ui.theme.TextSecondary
import com.dhavy.habitlevel.ui.viewmodel.HabitViewModel
import java.time.LocalDate

@Composable
fun WeeklyOverviewScreen(
    viewModel: HabitViewModel,
    onHabitClick: (Long) -> Unit
) {
    val habits by viewModel.activeHabits.collectAsStateWithLifecycle()
    val today = remember { LocalDate.now() }
    val todayEpochDay = remember { today.toEpochDay() }
    val weekStartEpochDay = remember { todayEpochDay - (today.dayOfWeek.value - 1) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 24.dp)
    ) {
        item {
            Text("Weekly Overview", style = MaterialTheme.typography.headlineMedium, color = TextPrimary)
            Text(
                "Minggu ini (Senin - Minggu)",
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary
            )
        }

        if (habits.isEmpty()) {
            item {
                Text("Belum ada habit buat ditampilkan.", color = TextSecondary)
            }
        } else {
            items(habits, key = { it.id }) { habit: Habit ->
                WeeklyHabitCard(
                    habit = habit,
                    viewModel = viewModel,
                    weekStartEpochDay = weekStartEpochDay,
                    todayEpochDay = todayEpochDay,
                    onClick = { onHabitClick(habit.id) }
                )
            }
        }
    }
}

@Composable
private fun WeeklyHabitCard(
    habit: Habit,
    viewModel: HabitViewModel,
    weekStartEpochDay: Long,
    todayEpochDay: Long,
    onClick: () -> Unit
) {
    var checkedDays by remember(habit.id) { mutableStateOf(emptySet<Long>()) }
    var percentage by remember(habit.id) { mutableStateOf(0f) }

    LaunchedEffect(habit.id) {
        viewModel.observeHabitCompletions(habit.id).collect { completions ->
            val weekly = WeeklyProgressCalculator.calculate(weekStartEpochDay, habit.targetDaysPerWeek, completions)
            checkedDays = weekly.checkedDays
            percentage = weekly.percentage
        }
    }

    Card(
        onClick = onClick,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = MaterialTheme.shapes.large
    ) {
        Column(Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    "${habit.category.emoji} ${habit.name}",
                    style = MaterialTheme.typography.titleMedium,
                    color = TextPrimary,
                    fontWeight = FontWeight.Bold
                )
                Text("${(percentage * 100).toInt()}%", style = MaterialTheme.typography.titleMedium, color = TextPrimary)
            }
            Spacer(Modifier.height(12.dp))
            WeekDotsRow(
                checkedDays = checkedDays,
                weekStartEpochDay = weekStartEpochDay,
                todayEpochDay = todayEpochDay
            )
        }
    }
}
