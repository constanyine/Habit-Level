package com.dhavy.habitlevel.ui.screens.habits

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.ui.platform.LocalContext
import com.dhavy.habitlevel.notification.NotificationScheduler
import com.dhavy.habitlevel.data.entity.Habit
import com.dhavy.habitlevel.domain.StreakCalculator
import com.dhavy.habitlevel.ui.components.HabitCard
import com.dhavy.habitlevel.ui.theme.TextPrimary
import com.dhavy.habitlevel.ui.theme.TextSecondary
import com.dhavy.habitlevel.ui.viewmodel.HabitViewModel
import java.time.LocalDate

@Composable
fun HabitListScreen(
    viewModel: HabitViewModel,
    onHabitClick: (Long) -> Unit
) {
    val habits by viewModel.activeHabits.collectAsStateWithLifecycle()
    var showAddDialog by remember { mutableStateOf(false) }
    val today = remember { LocalDate.now().toEpochDay() }
    val context = LocalContext.current

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(onClick = { showAddDialog = true }) {
                Icon(Icons.Filled.Add, contentDescription = "Tambah Habit")
            }
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(top = 16.dp, bottom = 80.dp)
        ) {
            item {
                Text("Semua Habit", style = MaterialTheme.typography.headlineMedium, color = TextPrimary)
            }
            if (habits.isEmpty()) {
                item {
                    Text(
                        "Belum ada habit. Tekan tombol + buat bikin yang pertama.",
                        color = TextSecondary,
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            } else {
                items(habits, key = { it.id }) { habit: Habit ->
                    HabitListRow(habit, today, viewModel) { onHabitClick(habit.id) }
                }
            }
        }
    }

    if (showAddDialog) {
        AddHabitDialog(
            onDismiss = { showAddDialog = false },
            onConfirm = { name, category, difficulty, target, hour, minute ->
                viewModel.createHabit(name, category, difficulty, target, hour, minute) { newId ->
                    if (hour != null) {
                        NotificationScheduler.scheduleDailyReminder(context, newId, name, hour, minute ?: 0)
                    }
                }
                showAddDialog = false
            }
        )
    }
}

@Composable
private fun HabitListRow(habit: Habit, today: Long, viewModel: HabitViewModel, onClick: () -> Unit) {
    var isDoneToday by remember(habit.id) { mutableStateOf(false) }
    var streak by remember(habit.id) { mutableStateOf(0) }

    LaunchedEffect(habit.id) {
        viewModel.observeHabitCompletions(habit.id).collect { completions ->
            isDoneToday = completions.any { it.epochDay == today }
            streak = StreakCalculator.currentStreak(completions, today)
        }
    }

    HabitCard(
        habit = habit,
        isDoneToday = isDoneToday,
        streak = streak,
        onToggle = { viewModel.toggleHabitDone(habit.id, today, isDoneToday) },
        onClick = onClick
    )
}
