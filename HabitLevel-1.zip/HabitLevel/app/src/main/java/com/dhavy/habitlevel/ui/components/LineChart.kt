package com.dhavy.habitlevel.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import com.dhavy.habitlevel.ui.theme.TextSecondary

/**
 * Line chart sederhana pakai Canvas Compose. Gak pakai library luar
 * biar gak ada risiko dependency gagal resolve — cukup buat kebutuhan
 * "progression" & "sleep tracker" yang diminta.
 *
 * @param values list nilai y (misal EXP harian, atau jam tidur harian)
 * @param labels label bawah tiap titik (misal tanggal singkat)
 */
@Composable
fun SimpleLineChart(
    values: List<Float>,
    labels: List<String>,
    lineColor: Color,
    modifier: Modifier = Modifier,
    emptyMessage: String = "Belum ada data"
) {
    Column(modifier = modifier) {
        if (values.isEmpty()) {
            Text(emptyMessage, color = TextSecondary, style = MaterialTheme.typography.bodyMedium)
            return@Column
        }

        val maxVal = (values.maxOrNull() ?: 1f).coerceAtLeast(1f)
        val minVal = (values.minOrNull() ?: 0f).coerceAtMost(0f)
        val range = (maxVal - minVal).coerceAtLeast(1f)

        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(160.dp)
                .padding(vertical = 8.dp)
        ) {
            val stepX = if (values.size > 1) size.width / (values.size - 1) else 0f
            val points = values.mapIndexed { index, value ->
                val x = stepX * index
                val normalized = (value - minVal) / range
                val y = size.height - (normalized * size.height)
                Offset(x, y)
            }

            // Grid garis horizontal tipis
            val gridLines = 3
            for (i in 0..gridLines) {
                val y = size.height / gridLines * i
                drawLine(
                    color = Color(0xFF2A2B45),
                    start = Offset(0f, y),
                    end = Offset(size.width, y),
                    strokeWidth = 1f
                )
            }

            // Garis progression
            for (i in 0 until points.size - 1) {
                drawLine(
                    color = lineColor,
                    start = points[i],
                    end = points[i + 1],
                    strokeWidth = 6f,
                    cap = androidx.compose.ui.graphics.StrokeCap.Round
                )
            }
            // Titik tiap data
            points.forEach { p ->
                drawCircle(color = lineColor, radius = 8f, center = p)
                drawCircle(color = Color.White, radius = 3f, center = p)
            }
        }

        if (labels.isNotEmpty()) {
            Column {
                androidx.compose.foundation.layout.Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = androidx.compose.foundation.layout.Arrangement.SpaceBetween
                ) {
                    // Cuma tampilin label pertama, tengah, terakhir biar gak numpuk
                    val shown = listOf(labels.first(), labels[labels.size / 2], labels.last())
                    shown.forEach {
                        Text(it, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    }
                }
            }
        }
    }
}
