package com.dhavy.habitlevel.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.dhavy.habitlevel.data.entity.HabitCompletion
import com.dhavy.habitlevel.data.repository.HabitRepository
import com.dhavy.habitlevel.domain.StreakCalculator
import com.dhavy.habitlevel.domain.WeeklyProgress
import com.dhavy.habitlevel.domain.WeeklyProgressCalculator
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import java.time.LocalDate

data class HabitDetailUiState(
    val completions: List<HabitCompletion> = emptyList(),
    val currentStreak: Int = 0,
    val weeklyProgress: WeeklyProgress? = null
)

class HabitDetailViewModel(
    private val repository: HabitRepository,
    private val habitId: Long,
    targetDaysPerWeek: Int
) : ViewModel() {

    private val today = LocalDate.now()
    private val todayEpochDay = today.toEpochDay()
    private val weekStartEpochDay = todayEpochDay - (today.dayOfWeek.value - 1) // Senin minggu ini
    private val targetDays = MutableStateFlow(targetDaysPerWeek)

    val uiState: StateFlow<HabitDetailUiState> = repository
        .observeCompletionsForHabit(habitId)
        .combine(targetDays) { completions, target ->
            HabitDetailUiState(
                completions = completions,
                currentStreak = StreakCalculator.currentStreak(completions, todayEpochDay),
                weeklyProgress = WeeklyProgressCalculator.calculate(weekStartEpochDay, target, completions)
            )
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), HabitDetailUiState())

    fun weekStart() = weekStartEpochDay
    fun todayDay() = todayEpochDay

    class Factory(
        private val repository: HabitRepository,
        private val habitId: Long,
        private val targetDaysPerWeek: Int
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return HabitDetailViewModel(repository, habitId, targetDaysPerWeek) as T
        }
    }
}
