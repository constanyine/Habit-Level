package com.dhavy.habitlevel.data.dao

import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Dao
import com.dhavy.habitlevel.data.entity.UserProgress
import kotlinx.coroutines.flow.Flow

@Dao
interface UserProgressDao {

    @Query("SELECT * FROM user_progress WHERE id = 1")
    fun observeProgress(): Flow<UserProgress?>

    @Query("SELECT * FROM user_progress WHERE id = 1")
    suspend fun getProgress(): UserProgress?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(progress: UserProgress)

    /** Dipakai fitur "Reset Progress" — kembalikan ke level 1, exp 0. */
    @Query("UPDATE user_progress SET level = 1, currentExp = 0, currentAttendanceStreak = 0 WHERE id = 1")
    suspend fun resetLevelAndExp()
}
