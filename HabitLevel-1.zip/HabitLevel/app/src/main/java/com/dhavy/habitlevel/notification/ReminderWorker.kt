package com.dhavy.habitlevel.notification

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import androidx.core.app.NotificationCompat
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.dhavy.habitlevel.data.AppDatabase

/**
 * Worker ini dijadwalkan per-habit (pakai WorkManager PeriodicWork atau
 * one-time work yang di-reschedule tiap hari) sesuai reminderHour/Minute
 * yang di-set di entity Habit.
 *
 * Kalimat notifikasi sengaja dibuat variatif biar gak berasa notif robot.
 */
class ReminderWorker(
    context: Context,
    params: WorkerParameters
) : CoroutineWorker(context, params) {

    companion object {
        const val KEY_HABIT_ID = "habit_id"
        const val KEY_HABIT_NAME = "habit_name"
        const val CHANNEL_ID = "habit_reminders"

        private val MOTIVATIONAL_LINES = listOf(
            "Waktunya naik level! Jangan lewatin \"%s\" hari ini.",
            "Streak-mu lagi bagus, jangan putus di \"%s\" ya.",
            "Karaktermu nunggu XP dari \"%s\". Gaskeun!",
            "Sedikit lagi buat progress mingguan \"%s\" tercapai."
        )
    }

    override suspend fun doWork(): Result {
        val habitId = inputData.getLong(KEY_HABIT_ID, -1)
        val habitName = inputData.getString(KEY_HABIT_NAME) ?: return Result.failure()

        // Pastikan habit masih aktif (belum di-archive) sebelum kirim notif
        val db = AppDatabase.getInstance(applicationContext)
        val habit = db.habitDao().getHabitById(habitId) ?: return Result.success()
        if (habit.isArchived) return Result.success()

        ensureChannel()

        val text = MOTIVATIONAL_LINES.random().format(habitName)
        val notification = NotificationCompat.Builder(applicationContext, CHANNEL_ID)
            .setContentTitle("HabitLevel")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_dialog_info) // ganti pakai icon custom
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .build()

        val manager = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(habitId.toInt(), notification)

        // Jadwalkan lagi buat besok di jam yang sama, biar reminder-nya harian
        habit.reminderHour?.let { hour ->
            NotificationScheduler.scheduleDailyReminder(
                applicationContext, habitId, habitName, hour, habit.reminderMinute ?: 0
            )
        }

        return Result.success()
    }

    private fun ensureChannel() {
        val manager = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (manager.getNotificationChannel(CHANNEL_ID) == null) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Pengingat Habit",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "Notifikasi pengingat buat checklist habit harian"
            }
            manager.createNotificationChannel(channel)
        }
    }
}
