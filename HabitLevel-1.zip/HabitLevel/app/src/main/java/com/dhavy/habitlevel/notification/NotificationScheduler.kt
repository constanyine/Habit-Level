package com.dhavy.habitlevel.notification

import android.content.Context
import androidx.work.Data
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import java.util.Calendar
import java.util.concurrent.TimeUnit

/**
 * Menjadwalkan reminder harian buat 1 habit. Dipanggil ulang tiap kali
 * worker selesai (di dalam ReminderWorker bisa dijadwal ulang untuk besok),
 * atau cukup dipanggil saat habit dibuat/diedit — implementasi ini pakai
 * OneTimeWork yang di-reschedule harian secara manual biar simpel dan gampang
 * dipahami dibanding PeriodicWork (yang minimum interval-nya 15 menit dan
 * kurang presisi buat jam spesifik).
 */
object NotificationScheduler {

    fun scheduleDailyReminder(context: Context, habitId: Long, habitName: String, hour: Int, minute: Int) {
        val delay = calculateInitialDelayMillis(hour, minute)

        val request = OneTimeWorkRequestBuilder<ReminderWorker>()
            .setInitialDelay(delay, TimeUnit.MILLISECONDS)
            .setInputData(
                Data.Builder()
                    .putLong(ReminderWorker.KEY_HABIT_ID, habitId)
                    .putString(ReminderWorker.KEY_HABIT_NAME, habitName)
                    .build()
            )
            .build()

        WorkManager.getInstance(context).enqueueUniqueWork(
            "reminder_habit_$habitId",
            ExistingWorkPolicy.REPLACE,
            request
        )
    }

    fun cancelReminder(context: Context, habitId: Long) {
        WorkManager.getInstance(context).cancelUniqueWork("reminder_habit_$habitId")
    }

    private fun calculateInitialDelayMillis(hour: Int, minute: Int): Long {
        val now = Calendar.getInstance()
        val target = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0)
        }
        if (target.before(now)) {
            target.add(Calendar.DAY_OF_MONTH, 1)
        }
        return target.timeInMillis - now.timeInMillis
    }
}
