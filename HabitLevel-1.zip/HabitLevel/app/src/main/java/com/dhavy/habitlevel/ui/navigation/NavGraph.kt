package com.dhavy.habitlevel.ui.navigation

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarViewWeek
import androidx.compose.material.icons.filled.Checklist
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Bedtime
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import androidx.navigation.NavType
import com.dhavy.habitlevel.data.AppContainer
import com.dhavy.habitlevel.ui.screens.dashboard.DashboardScreen
import com.dhavy.habitlevel.ui.screens.habits.HabitListScreen
import com.dhavy.habitlevel.ui.screens.profile.ProfileScreen
import com.dhavy.habitlevel.ui.screens.settings.SettingsScreen
import com.dhavy.habitlevel.ui.screens.sleep.SleepScreen
import com.dhavy.habitlevel.ui.screens.weekly.HabitDetailScreen
import com.dhavy.habitlevel.ui.screens.weekly.WeeklyOverviewScreen
import com.dhavy.habitlevel.ui.viewmodel.HabitViewModel
import com.dhavy.habitlevel.ui.viewmodel.SleepViewModel
import kotlinx.coroutines.flow.first

private sealed class BottomDest(val route: String, val label: String, val icon: androidx.compose.ui.graphics.vector.ImageVector) {
    object Dashboard : BottomDest("dashboard", "Home", Icons.Filled.Home)
    object Habits : BottomDest("habits", "Habits", Icons.Filled.Checklist)
    object Weekly : BottomDest("weekly", "Weekly", Icons.Filled.CalendarViewWeek)
    object Sleep : BottomDest("sleep", "Sleep", Icons.Filled.Bedtime)
    object Profile : BottomDest("profile", "Profile", Icons.Filled.Person)
}

private val bottomItems = listOf(
    BottomDest.Dashboard, BottomDest.Habits, BottomDest.Weekly, BottomDest.Sleep, BottomDest.Profile
)

@Composable
fun HabitLevelNavGraph(container: AppContainer) {
    val navController = rememberNavController()
    val habitViewModel: HabitViewModel = viewModel(factory = HabitViewModel.Factory(container.habitRepository))
    val sleepViewModel: SleepViewModel = viewModel(factory = SleepViewModel.Factory(container.sleepRepository))

    Scaffold(
        bottomBar = {
            val backStackEntry by navController.currentBackStackEntryAsState()
            val currentRoute = backStackEntry?.destination

            // Sembunyikan bottom bar di layar detail/settings biar fokus
            val showBottomBar = bottomItems.any { it.route == currentRoute?.route }
            if (showBottomBar) {
                NavigationBar {
                    bottomItems.forEach { dest ->
                        val selected = currentRoute?.hierarchy?.any { it.route == dest.route } == true
                        NavigationBarItem(
                            selected = selected,
                            onClick = {
                                navController.navigate(dest.route) {
                                    popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon = { Icon(dest.icon, contentDescription = dest.label) },
                            label = { Text(dest.label) }
                        )
                    }
                }
            }
        }
    ) { padding ->
        NavHost(
            navController = navController,
            startDestination = BottomDest.Dashboard.route,
            modifier = Modifier.padding(padding)
        ) {
            composable(BottomDest.Dashboard.route) {
                DashboardScreen(
                    viewModel = habitViewModel,
                    onHabitClick = { id -> navController.navigate("habit_detail/$id") },
                    onMarkAttendance = { habitViewModel.markAttendance() }
                )
            }
            composable(BottomDest.Habits.route) {
                HabitListScreen(
                    viewModel = habitViewModel,
                    onHabitClick = { id -> navController.navigate("habit_detail/$id") }
                )
            }
            composable(BottomDest.Weekly.route) {
                WeeklyOverviewScreen(
                    viewModel = habitViewModel,
                    onHabitClick = { id -> navController.navigate("habit_detail/$id") }
                )
            }
            composable(BottomDest.Sleep.route) {
                SleepScreen(viewModel = sleepViewModel)
            }
            composable(BottomDest.Profile.route) {
                ProfileScreen(
                    viewModel = habitViewModel,
                    onOpenSettings = { navController.navigate("settings") }
                )
            }
            composable(
                "habit_detail/{habitId}",
                arguments = listOf(navArgument("habitId") { type = NavType.LongType })
            ) { backStackEntry ->
                val habitId = backStackEntry.arguments?.getLong("habitId") ?: return@composable
                var habit by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf<com.dhavy.habitlevel.data.entity.Habit?>(null) }
                androidx.compose.runtime.LaunchedEffect(habitId) {
                    habit = container.habitRepository.observeActiveHabits().first().find { it.id == habitId }
                }
                habit?.let {
                    HabitDetailScreen(
                        habit = it,
                        repository = container.habitRepository,
                        onBack = { navController.popBackStack() }
                    )
                }
            }
            composable("settings") {
                SettingsScreen(
                    repository = container.habitRepository,
                    onBack = { navController.popBackStack() }
                )
            }
        }
    }
}
