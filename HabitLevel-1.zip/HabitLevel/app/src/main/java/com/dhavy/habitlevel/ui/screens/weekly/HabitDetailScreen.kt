package com.dhavy.habitlevel.ui.screens.weekly

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.dhavy.habitlevel.data.entity.Habit
import com.dhavy.habitlevel.data.repository.HabitRepository
import com.dhavy.habitlevel.ui.components.StreakBadge
import com.dhavy.habitlevel.ui.components.WeekDotsRow
import com.dhavy.habitlevel.ui.theme.AccentPrimary
import com.dhavy.habitlevel.ui.theme.TextPrimary
import com.dhavy.habitlevel.ui.theme.TextSecondary
import com.dhavy.habitlevel.ui.viewmodel.HabitDetailViewModel
import java.time.LocalDate

@Composable
fun HabitDetailScreen(
    habit: Habit,
    repository: HabitRepository,
    onBack: () -> Unit
) {
    val viewModel: HabitDetailViewModel = viewModel(
        factory = HabitDetailViewModel.Factory(repository, habit.id, habit.targetDaysPerWeek)
    )
    val state by viewModel.uiState.collectAsStateWithLifecycle()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) {
                Icon(Icons.Filled.ArrowBack, contentDescription = "Kembali", tint = TextPrimary)
            }
            Spacer(Modifier.width(4.dp))
            Column {
                Text(habit.name, style = MaterialTheme.typography.headlineMedium, color = TextPrimary)
                Text(
                    "${habit.category.emoji} ${habit.category.displayName} · ${habit.difficulty.name}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary
                )
            }
        }

        Spacer(Modifier.height(16.dp))
        StreakBadge(state.currentStreak)

        Spacer(Modifier.height(20.dp))
        Text("Progress Minggu Ini", style = MaterialTheme.typography.titleLarge, color = TextPrimary, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(4.dp))
        state.weeklyProgress?.let { weekly ->
            Text(
                "Target: ${weekly.targetDays} hari/minggu — ${(weekly.percentage * 100).toInt()}% tercapai",
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary
            )
            Spacer(Modifier.height(8.dp))
            LinearProgressIndicator(
                progress = { weekly.percentage },
                modifier = Modifier.fillMaxWidth().height(10.dp),
                color = AccentPrimary
            )
            Spacer(Modifier.height(16.dp))
            WeekDotsRow(
                checkedDays = weekly.checkedDays,
                weekStartEpochDay = viewModel.weekStart(),
                todayEpochDay = viewModel.todayDay()
            )
        }

        Spacer(Modifier.height(28.dp))
        Text("Riwayat 30 Hari Terakhir", style = MaterialTheme.typography.titleLarge, color = TextPrimary, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))

        val today = LocalDate.now().toEpochDay()
        val last30 = (29 downTo 0).map { today - it }
        val completedSet = state.completions.map { it.epochDay }.toHashSet()
        val values = last30.map { if (completedSet.contains(it)) 1f else 0f }
        val labels = last30.map {
            LocalDate.ofEpochDay(it).dayOfMonth.toString()
        }

        com.dhavy.habitlevel.ui.components.SimpleLineChart(
            values = values,
            labels = labels,
            lineColor = AccentPrimary,
            emptyMessage = "Belum ada riwayat checklist"
        )
    }
}
