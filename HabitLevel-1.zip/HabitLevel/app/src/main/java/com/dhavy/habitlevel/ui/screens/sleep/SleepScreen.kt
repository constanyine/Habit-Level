package com.dhavy.habitlevel.ui.screens.sleep

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.dhavy.habitlevel.ui.components.SimpleLineChart
import com.dhavy.habitlevel.ui.theme.AccentSecondary
import com.dhavy.habitlevel.ui.theme.TextPrimary
import com.dhavy.habitlevel.ui.theme.TextSecondary
import com.dhavy.habitlevel.ui.viewmodel.SleepViewModel
import java.time.LocalDate

@Composable
fun SleepScreen(viewModel: SleepViewModel) {
    val entries by viewModel.recentSleep.collectAsStateWithLifecycle()
    var showDialog by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("Sleep Tracker", style = MaterialTheme.typography.headlineMedium, color = TextPrimary)
                Text("30 hari terakhir", style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
            }
            Button(onClick = { showDialog = true }) {
                Text("Catat Tidur")
            }
        }

        Spacer(Modifier.height(20.dp))

        val today = LocalDate.now().toEpochDay()
        val last30 = (29 downTo 0).map { today - it }
        val entryMap = entries.associateBy { it.epochDay }
        val values = last30.map { day -> (entryMap[day]?.sleepDurationMinutes ?: 0) / 60f }
        val labels = last30.map { LocalDate.ofEpochDay(it).dayOfMonth.toString() }

        val avgHours = if (values.any { it > 0f }) values.filter { it > 0f }.average().toFloat() else 0f

        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
            Column(Modifier.padding(16.dp)) {
                Text(
                    "Rata-rata: ${"%.1f".format(avgHours)} jam/malam",
                    style = MaterialTheme.typography.titleMedium,
                    color = TextPrimary,
                    fontWeight = FontWeight.Bold
                )
                SimpleLineChart(
                    values = values,
                    labels = labels,
                    lineColor = AccentSecondary,
                    emptyMessage = "Belum ada catatan tidur"
                )
            }
        }
    }

    if (showDialog) {
        LogSleepDialog(
            onDismiss = { showDialog = false },
            onConfirm = { hours, quality ->
                viewModel.logSleep(hours, quality)
                showDialog = false
            }
        )
    }
}

@Composable
private fun LogSleepDialog(
    onDismiss: () -> Unit,
    onConfirm: (hours: Float, quality: Int?) -> Unit
) {
    var hours by remember { mutableStateOf(7f) }
    var quality by remember { mutableStateOf(3) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Catat Tidur Semalam") },
        text = {
            Column {
                Text("Durasi: ${"%.1f".format(hours)} jam")
                Slider(value = hours, onValueChange = { hours = it }, valueRange = 0f..12f, steps = 23)
                Spacer(Modifier.height(12.dp))
                Text("Kualitas tidur: $quality/5")
                Slider(
                    value = quality.toFloat(),
                    onValueChange = { quality = it.toInt() },
                    valueRange = 1f..5f,
                    steps = 3
                )
            }
        },
        confirmButton = {
            TextButton(onClick = { onConfirm(hours, quality) }) { Text("Simpan") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Batal") }
        }
    )
}
