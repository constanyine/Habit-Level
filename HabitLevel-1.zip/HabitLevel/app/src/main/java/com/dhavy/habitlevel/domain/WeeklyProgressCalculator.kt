package com.dhavy.habitlevel.domain

import com.dhavy.habitlevel.data.entity.HabitCompletion

data class WeeklyProgress(
    val checkedDays: Set<Long>,   // epochDay yang sudah checklist minggu ini
    val targetDays: Int,          // limit yang di-set user, misal 6
    val percentage: Float         // 0f..1f, sudah dicap max 100%
)

/**
 * Menghitung progress mingguan berdasarkan "limit" custom milik habit,
 * bukan selalu dibagi 7. Misal limit = 6 hari, dan user sudah checklist
 * 6 hari di minggu itu -> 100%, walau masih ada 1 hari tersisa di minggu itu.
 */
object WeeklyProgressCalculator {

    /**
     * @param weekStartEpochDay epochDay hari Senin di minggu yang mau dihitung
     * @param completions semua completion untuk 1 habit (boleh lebih dari 1 minggu, akan difilter)
     */
    fun calculate(
        weekStartEpochDay: Long,
        targetDaysPerWeek: Int,
        completions: List<HabitCompletion>
    ): WeeklyProgress {
        val weekEndEpochDay = weekStartEpochDay + 6
        val checkedThisWeek = completions
            .map { it.epochDay }
            .filter { it in weekStartEpochDay..weekEndEpochDay }
            .toSet()

        val target = targetDaysPerWeek.coerceIn(1, 7)
        val pct = (checkedThisWeek.size.toFloat() / target).coerceAtMost(1f)

        return WeeklyProgress(
            checkedDays = checkedThisWeek,
            targetDays = target,
            percentage = pct
        )
    }
}
