package com.dhavy.habitlevel.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverter
import androidx.room.TypeConverters
import com.dhavy.habitlevel.data.dao.HabitDao
import com.dhavy.habitlevel.data.dao.SleepDao
import com.dhavy.habitlevel.data.dao.UserProgressDao
import com.dhavy.habitlevel.data.entity.*

class Converters {
    @TypeConverter
    fun fromCategory(value: HabitCategory): String = value.name

    @TypeConverter
    fun toCategory(value: String): HabitCategory = HabitCategory.valueOf(value)

    @TypeConverter
    fun fromDifficulty(value: HabitDifficulty): String = value.name

    @TypeConverter
    fun toDifficulty(value: String): HabitDifficulty = HabitDifficulty.valueOf(value)
}

@Database(
    entities = [Habit::class, HabitCompletion::class, UserProgress::class, SleepEntry::class],
    version = 1,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun habitDao(): HabitDao
    abstract fun userProgressDao(): UserProgressDao
    abstract fun sleepDao(): SleepDao

    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "habitlevel.db"
                ).build().also { INSTANCE = it }
            }
    }
}
