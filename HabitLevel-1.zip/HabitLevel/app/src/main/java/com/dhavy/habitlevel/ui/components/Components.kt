package com.dhavy.habitlevel.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.outlined.Circle
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.dhavy.habitlevel.data.entity.Habit
import com.dhavy.habitlevel.data.entity.HabitCategory
import com.dhavy.habitlevel.domain.ExpCalculator
import com.dhavy.habitlevel.ui.theme.*

/** Kartu besar di Dashboard/Profile nunjukin Level + progress bar EXP. */
@Composable
fun LevelCard(level: Int, currentExp: Int, modifier: Modifier = Modifier) {
    val expNeeded = ExpCalculator.expRequiredForLevel(level)
    val progress = (currentExp.toFloat() / expNeeded).coerceIn(0f, 1f)
    val animatedProgress by animateFloatAsState(targetValue = progress, animationSpec = tween(600), label = "exp")

    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceElevated)
    ) {
        Column(Modifier.padding(20.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(56.dp)
                        .clip(CircleShape)
                        .background(AccentPrimary),
                    contentAlignment = Alignment.Center
                ) {
                    Text("Lv.$level", color = Color.White, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.width(16.dp))
                Column {
                    Text("Level $level", style = MaterialTheme.typography.titleLarge, color = TextPrimary)
                    Text("$currentExp / $expNeeded EXP", style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
                }
            }
            Spacer(Modifier.height(14.dp))
            LinearProgressIndicator(
                progress = { animatedProgress },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(10.dp)
                    .clip(RoundedCornerShape(8.dp)),
                color = ExpBar,
                trackColor = SurfaceDark
            )
        }
    }
}

@Composable
fun StreakBadge(streak: Int, modifier: Modifier = Modifier) {
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(50))
            .background(SurfaceElevated)
            .padding(horizontal = 12.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Filled.LocalFireDepartment, contentDescription = null, tint = StreakFire, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(4.dp))
        Text("$streak hari", color = TextPrimary, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
    }
}

fun categoryColor(category: HabitCategory): Color = when (category) {
    HabitCategory.FISIKAL -> CategoryFisikal
    HabitCategory.MENTAL -> CategoryMental
    HabitCategory.INTELEKTUAL -> CategoryIntelektual
    HabitCategory.SOSIAL -> CategorySosial
    HabitCategory.SPIRITUAL -> CategorySpiritual
    HabitCategory.KREATIVITAS -> CategoryKreativitas
    HabitCategory.FINANSIAL -> CategoryFinansial
    HabitCategory.PRODUKTIVITAS -> CategoryProduktivitas
}

/** Kartu satu habit di list, dengan tombol checklist hari ini. */
@Composable
fun HabitCard(
    habit: Habit,
    isDoneToday: Boolean,
    streak: Int,
    onToggle: () -> Unit,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .clickable { onClick() },
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceDark)
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(10.dp)
                    .clip(CircleShape)
                    .background(categoryColor(habit.category))
            )
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(habit.name, style = MaterialTheme.typography.titleMedium, color = TextPrimary)
                Spacer(Modifier.height(4.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        "${habit.category.emoji} ${habit.category.displayName}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextSecondary
                    )
                    if (streak > 0) {
                        Spacer(Modifier.width(8.dp))
                        StreakBadge(streak)
                    }
                }
            }
            Spacer(Modifier.width(8.dp))
            IconButton(onClick = onToggle) {
                Icon(
                    imageVector = if (isDoneToday) Icons.Filled.CheckCircle else Icons.Outlined.Circle,
                    contentDescription = "Checklist",
                    tint = if (isDoneToday) SuccessGreen else TextSecondary,
                    modifier = Modifier.size(32.dp)
                )
            }
        }
    }
}

/** 7 titik hari (Sen-Min) buat weekly overview — kalau sudah checklist jadi solid. */
@Composable
fun WeekDotsRow(
    checkedDays: Set<Long>,
    weekStartEpochDay: Long,
    todayEpochDay: Long,
    modifier: Modifier = Modifier
) {
    val labels = listOf("S", "S", "R", "K", "J", "S", "M") // Sen Sel Rab Kam Jum Sab Min
    Row(modifier = modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        for (i in 0..6) {
            val day = weekStartEpochDay + i
            val isChecked = checkedDays.contains(day)
            val isFuture = day > todayEpochDay
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Box(
                    modifier = Modifier
                        .size(30.dp)
                        .clip(CircleShape)
                        .background(
                            when {
                                isChecked -> SuccessGreen
                                isFuture -> SurfaceDark
                                else -> SurfaceElevated
                            }
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    if (isChecked) {
                        Icon(Icons.Filled.CheckCircle, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                    }
                }
                Spacer(Modifier.height(4.dp))
                Text(labels[i], style = MaterialTheme.typography.labelSmall, color = TextSecondary)
            }
        }
    }
}
