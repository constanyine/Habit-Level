package com.dhavy.habitlevel

import android.app.Application
import com.dhavy.habitlevel.data.AppContainer

class HabitLevelApplication : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
    }
}
