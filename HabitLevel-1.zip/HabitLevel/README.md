# HabitLevel — RPG Habit Tracker (Solo Leveling Style)

## Stack
- **Kotlin** + **Jetpack Compose** (UI modern, mirip sosmed, gampang dianimasi)
- **Room** (database lokal — semua data habit, exp, sleep, streak tersimpan offline)
- **WorkManager** + **AlarmManager** (notifikasi pengingat, jalan walau app ditutup)
- **MVVM** (ViewModel + Repository + StateFlow) — biar UI reaktif & gampang di-maintain
- **Vico / MPAndroidChart** (opsional, buat diagram garis progression & sleep — tinggal pilih salah satu)

## Struktur folder
```
data/entity/       -> Room Entities (tabel database)
data/dao/          -> Data Access Object (query database)
data/repository/   -> Jembatan antara DAO dan ViewModel
domain/            -> Logic inti game (EXP, Level, Streak, Weekly progress)
notification/      -> Worker buat reminder
util/              -> helper (tanggal, formatter, dll)
```

## Alur sistem EXP & Level (inti "game engine"-nya)
File kunci: `domain/ExpCalculator.kt`

1. User checklist habit di hari tertentu → dicatat di `HabitCompletion`
2. `ExpCalculator.calculateExpForCompletion()` hitung EXP dari:
   - Difficulty habit (Easy/Medium/Hard) → base 5/10/15 EXP
   - Bonus streak (setiap kelipatan 5 hari +1, max +10)
3. EXP masuk ke `UserProgress`, sistem cek apakah `currentExp >= expToNextLevel`
4. Kalau naik level → sisa EXP dibawa ke level berikutnya (gak hangus), level up event dikirim ke UI (buat animasi/notif "LEVEL UP!")
5. `expToNextLevel` pakai kurva: `100 * level^1.5` (dibulatkan) — biar makin lama makin butuh effort, khas RPG

## Weekly Progress & Limit
File kunci: `domain/WeeklyProgressCalculator.kt`

- Tiap habit punya field `targetDaysPerWeek` (limit) — misal diisi 6, artinya 100% tercapai kalau udah checklist 6 hari dalam minggu itu (walau minggu ada 7 hari)
- Progress % = `min(1.0, checkedDays / targetDaysPerWeek)`
- Bisa juga dipakai buat limit jangka panjang (limit sampai minggu ke berapa) — tinggal ganti basis perhitungan ke total minggu program habit itu berjalan

## Kategori default (bisa ditambah di `HabitCategory.kt`)
Fisikal, Mental, Intelektual, Sosial, Spiritual, Kreativitas, Finansial, Produktivitas

## Fitur yang sudah di-skeleton di sini
- [x] Entity: Habit, HabitCompletion, UserProgress, SleepEntry, AttendanceLog
- [x] DAO lengkap untuk semua entity
- [x] ExpCalculator (sistem leveling otomatis)
- [x] StreakCalculator
- [x] WeeklyProgressCalculator (dengan limit custom)
- [x] ReminderWorker (kerangka notifikasi)
- [x] Repository layer

## Yang perlu kamu lanjutkan di Android Studio
- [ ] UI Compose (Dashboard, Habit List, Weekly Overview, Level/Profile screen, Sleep chart)
- [ ] Setup grafik (Vico direkomendasikan, lebih modern & Compose-native daripada MPAndroidChart)
- [ ] Setup notification channel + permission (Android 13+ perlu POST_NOTIFICATIONS runtime permission)
- [ ] Layar Settings dengan tombol "Reset Progress" (dialog konfirmasi 2 langkah)
- [ ] Splash/onboarding kalau mau

Kalau mau, bagian UI Compose-nya bisa kita lanjut bikin di sesi berikutnya — kasih tau screen mana yang mau diprioritasin duluan (Dashboard atau Habit List biasanya paling enak buat mulai).
